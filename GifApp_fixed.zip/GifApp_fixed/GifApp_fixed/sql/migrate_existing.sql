-- обновление исходной базы gif_app без удаления и изменения строк.
-- перед запуском: резервная копия и остановка api. ddl в mysql не откатывается транзакцией.
-- запускать mysql-клиентом или workbench с правами alter/create routine; не использовать --force.
-- значения паролей остаются исходными; скрипт не хеширует и не переписывает их.
use `gif_app`;

delimiter $$
drop procedure if exists `migrate_gifapp_fixed`$$
create procedure `migrate_gifapp_fixed`()
begin
    declare previous_fk_checks int default @@foreign_key_checks;
    declare exit handler for sqlexception
    begin
        set foreign_key_checks = previous_fk_checks;
        resignal;
    end;
    -- все проверки выполняются до первого изменения таблиц.
    if (select count(*) from information_schema.tables
        where table_schema = database() and table_name in
        ('roles','statuses','type_reactions','users','gif_animations','publications','comments','reactions')) <> 8 then
        signal sqlstate '45000' set message_text = 'expected the 8 original gif_app tables; no tables changed';
    end if;
    if exists (select 1 from users where char_length(user_name) <> char_length(trim(user_name))
               or char_length(user_email) <> char_length(trim(user_email))) then
        signal sqlstate '45000' set message_text = 'trim spaces in usernames/emails manually after checking data; no tables changed';
    end if;
    if exists (select 1 from users group by trim(user_name) having count(*) > 1) then
        signal sqlstate '45000' set message_text = 'duplicate usernames; resolve manually after backup; no tables changed';
    end if;
    if exists (select 1 from users group by trim(user_email) having count(*) > 1) then
        signal sqlstate '45000' set message_text = 'duplicate emails; resolve manually after backup; no tables changed';
    end if;
    if exists (select 1 from reactions group by id_publication, id_user having count(*) > 1) then
        signal sqlstate '45000' set message_text = 'duplicate user reactions per publication; resolve manually; no tables changed';
    end if;
    if exists (select 1 from roles where id_role <= 0)
       or exists (select 1 from statuses where id_status <= 0)
       or exists (select 1 from type_reactions where id_type_reaction <= 0)
       or exists (select 1 from users where id_user <= 0)
       or exists (select 1 from gif_animations where id_gif <= 0)
       or exists (select 1 from publications where id_publication <= 0)
       or exists (select 1 from comments where id_comment <= 0)
       or exists (select 1 from reactions where id_reaction <= 0) then
        signal sqlstate '45000' set message_text = 'non-positive ids require manual review; no tables changed';
    end if;
    if exists (select 1 from users u left join roles r on r.id_role=u.id_role where r.id_role is null)
       or exists (select 1 from users u left join statuses s on s.id_status=u.id_status where s.id_status is null)
       or exists (select 1 from gif_animations g left join users u on u.id_user=g.id_user where u.id_user is null)
       or exists (select 1 from publications p left join users u on u.id_user=p.id_user where u.id_user is null)
       or exists (select 1 from publications p left join gif_animations g on g.id_gif=p.id_gif where g.id_gif is null)
       or exists (select 1 from comments c left join users u on u.id_user=c.id_user where u.id_user is null)
       or exists (select 1 from comments c left join publications p on p.id_publication=c.id_publication where p.id_publication is null)
       or exists (select 1 from reactions r left join users u on u.id_user=r.id_user where u.id_user is null)
       or exists (select 1 from reactions r left join publications p on p.id_publication=r.id_publication where p.id_publication is null)
       or exists (select 1 from reactions r left join type_reactions t on t.id_type_reaction=r.id_type_reaction where t.id_type_reaction is null) then
        signal sqlstate '45000' set message_text = 'orphan foreign keys require manual review; no tables changed';
    end if;
    -- mysql требует временно отключить проверки при изменении связанного первичного ключа.
    -- исходные ссылки проверены выше; приложение должно быть остановлено.
    set foreign_key_checks = 0;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'roles' and column_name = 'id_role' and extra like '%auto_increment%') then
        alter table `roles` modify `id_role` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'statuses' and column_name = 'id_status' and extra like '%auto_increment%') then
        alter table `statuses` modify `id_status` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'type_reactions' and column_name = 'id_type_reaction' and extra like '%auto_increment%') then
        alter table `type_reactions` modify `id_type_reaction` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'users' and column_name = 'id_user' and extra like '%auto_increment%') then
        alter table `users` modify `id_user` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'gif_animations' and column_name = 'id_gif' and extra like '%auto_increment%') then
        alter table `gif_animations` modify `id_gif` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'publications' and column_name = 'id_publication' and extra like '%auto_increment%') then
        alter table `publications` modify `id_publication` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'comments' and column_name = 'id_comment' and extra like '%auto_increment%') then
        alter table `comments` modify `id_comment` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.columns where table_schema = database()
                   and table_name = 'reactions' and column_name = 'id_reaction' and extra like '%auto_increment%') then
        alter table `reactions` modify `id_reaction` int not null auto_increment;
    end if;

    if not exists (select 1 from information_schema.statistics where table_schema = database()
                   and table_name = 'users' and index_name = 'ux_users_name') then
        alter table `users` add unique key `ux_users_name` (`user_name`);
    end if;

    if not exists (select 1 from information_schema.statistics where table_schema = database()
                   and table_name = 'users' and index_name = 'ux_users_email') then
        alter table `users` add unique key `ux_users_email` (`user_email`);
    end if;

    if not exists (select 1 from information_schema.statistics where table_schema = database()
                   and table_name = 'reactions' and index_name = 'ux_reactions_publication_user') then
        alter table `reactions` add unique key `ux_reactions_publication_user` (`id_publication`, `id_user`);
    end if;

    if exists (select 1 from information_schema.referential_constraints where constraint_schema = database()
               and table_name = 'comments' and constraint_name = 'fk_comments_publications' and lower(delete_rule) <> 'cascade') then
        alter table `comments` drop foreign key `fk_comments_publications`;
    end if;
    if not exists (select 1 from information_schema.referential_constraints where constraint_schema = database()
                   and table_name = 'comments' and constraint_name = 'fk_comments_publications') then
        alter table `comments` add constraint `fk_comments_publications` foreign key (`id_publication`)
            references `publications` (`id_publication`) on delete cascade;
    end if;

    if exists (select 1 from information_schema.referential_constraints where constraint_schema = database()
               and table_name = 'reactions' and constraint_name = 'fk_reactions_publications' and lower(delete_rule) <> 'cascade') then
        alter table `reactions` drop foreign key `fk_reactions_publications`;
    end if;
    if not exists (select 1 from information_schema.referential_constraints where constraint_schema = database()
                   and table_name = 'reactions' and constraint_name = 'fk_reactions_publications') then
        alter table `reactions` add constraint `fk_reactions_publications` foreign key (`id_publication`)
            references `publications` (`id_publication`) on delete cascade;
    end if;

    set foreign_key_checks = previous_fk_checks;
end$$
call `migrate_gifapp_fixed`()$$
drop procedure `migrate_gifapp_fixed`$$
delimiter ;

select 'migration completed; original rows and passwords preserved' as result;
