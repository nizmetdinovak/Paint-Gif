-- новая база для исправленной версии gifapp; только для пустой базы.
-- существующие таблицы не удаляются; для старой базы используйте migrate_existing.sql.
-- исходные строки данных, включая пароли, сохранены без изменений.
create database if not exists `gif_app` character set utf8mb4 collate utf8mb4_0900_ai_ci;
use `gif_app`;
set names utf8mb4;

-- roles
create table `roles` (
  `id_role` int not null auto_increment,
  `role_name` varchar(5) not null,
  primary key (`id_role`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- statuses
create table `statuses` (
  `id_status` int not null auto_increment,
  `status` varchar(9) not null,
  primary key (`id_status`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- type_reactions
create table `type_reactions` (
  `id_type_reaction` int not null auto_increment,
  `name_type_reaction` varchar(7) not null,
  primary key (`id_type_reaction`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- users
create table `users` (
  `id_user` int not null auto_increment,
  `id_role` int not null,
  `user_name` varchar(25) not null,
  `user_email` varchar(25) not null,
  `user_password` varchar(8) not null,
  `id_status` int not null,
  primary key (`id_user`),
  unique key `ux_users_name` (`user_name`),
  unique key `ux_users_email` (`user_email`),
  key `fk_users_roles_idx` (`id_role`),
  key `fk_users_statuses_idx` (`id_status`),
  constraint `fk_users_roles` foreign key (`id_role`) references `roles` (`id_role`),
  constraint `fk_users_statuses` foreign key (`id_status`) references `statuses` (`id_status`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- gif_animations
create table `gif_animations` (
  `id_gif` int not null auto_increment,
  `name_gif` varchar(35) not null,
  `description_gif` text not null,
  `creation_date` date not null,
  `id_user` int not null,
  `frame_count` int not null,
  `playback_speed` float not null,
  `gif_path` text not null,
  primary key (`id_gif`),
  key `fk_gifs_users_idx` (`id_user`),
  constraint `fk_gifs_users` foreign key (`id_user`) references `users` (`id_user`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- publications
create table `publications` (
  `id_publication` int not null auto_increment,
  `id_gif` int not null,
  `id_user` int not null,
  `publication_date` datetime(3) not null,
  primary key (`id_publication`),
  key `fk_publications_users_idx` (`id_user`),
  key `fk_publications_gifs_idx` (`id_gif`),
  constraint `fk_publications_gifs` foreign key (`id_gif`) references `gif_animations` (`id_gif`),
  constraint `fk_publications_users` foreign key (`id_user`) references `users` (`id_user`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- comments
create table `comments` (
  `id_comment` int not null auto_increment,
  `id_publication` int not null,
  `id_user` int not null,
  `comment_text` text not null,
  `comment_date` date not null,
  primary key (`id_comment`),
  key `fk_comments_users_idx` (`id_user`),
  key `fk_comments_publications_idx` (`id_publication`),
  constraint `fk_comments_publications` foreign key (`id_publication`) references `publications` (`id_publication`) on delete cascade,
  constraint `fk_comments_users` foreign key (`id_user`) references `users` (`id_user`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- reactions
create table `reactions` (
  `id_reaction` int not null auto_increment,
  `id_publication` int not null,
  `id_user` int not null,
  `id_type_reaction` int not null,
  `reaction_date` date not null,
  primary key (`id_reaction`),
  unique key `ux_reactions_publication_user` (`id_publication`, `id_user`),
  key `fk_reactions_rype_reactions_idx` (`id_type_reaction`),
  key `fk_reactions_users_idx` (`id_user`),
  key `fk_reactions_publications_idx` (`id_publication`),
  constraint `fk_reactions_publications` foreign key (`id_publication`) references `publications` (`id_publication`) on delete cascade,
  constraint `fk_reactions_rype_reactions` foreign key (`id_type_reaction`) references `type_reactions` (`id_type_reaction`),
  constraint `fk_reactions_users` foreign key (`id_user`) references `users` (`id_user`)
) engine=innodb default charset=utf8mb4 collate=utf8mb4_0900_ai_ci;

-- исходные данные из присланного дампа.
start transaction;
insert into `roles` values (1,'admin'),(2,'user');
insert into `statuses` values (1,'is_active'),(2,'is_banned');
insert into `type_reactions` values (1,'Дизлайк'),(2,'Лайк');
insert into `users` values (1,2,'Chto_nibud','Chto_nibud@gmail.com','Ilnara',1),(2,2,'Ivanov','Ivanov@gmail.com','password',2),(3,2,'Pola_rity','Pola_rity@gmail.com','123456rt',1),(4,1,'Polina_the_best','polinathebest@gmail.com','best1234',1),(5,2,'Robin','Robin_Good@gmail.com','qwe12345',1);
insert into `gif_animations` values (1,'Кот идёт','Анимация кота','2026-10-05',1,5,10,'/gif/cat.gif');
insert into `publications` values (1,1,1,'2026-10-05 00:00:00.000');
insert into `comments` values (1,1,4,'Милый котик','2026-10-05');
insert into `reactions` values (1,1,1,2,'2026-10-05');
commit;
