using System.Text;

namespace GifApp.Services;

public sealed record StoredGif(string Path, int FrameCount, float PlaybackSpeed);

public sealed class GifFileStorage
{
    public const long MaxFileBytes = 20 * 1024 * 1024;
    private readonly string root;
    private readonly ILogger<GifFileStorage> logger;

    public GifFileStorage(IConfiguration configuration, IWebHostEnvironment environment, ILogger<GifFileStorage> logger)
    {
        this.logger = logger;
        var configured = configuration["Files:Root"] ?? "data/uploads";
        root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(Path.IsPathRooted(configured) ? configured : Path.Combine(environment.ContentRootPath, configured)));
        Directory.CreateDirectory(Path.Combine(root, "gifs"));
    }

    public async Task<StoredGif> SaveAsync(IFormFile file, CancellationToken cancellationToken = default)
{
    if (file.Length <= 0 || file.Length > MaxFileBytes)
        throw new ArgumentException("Загрузите GIF-файл размером от 1 байта до 20 МБ.");
    await using var memory = new MemoryStream((int)file.Length);
    await file.CopyToAsync(memory, cancellationToken);
    if (memory.Length > MaxFileBytes)
        throw new ArgumentException("Размер GIF-файла превышает 20 МБ.");
    var bytes = memory.ToArray();
    var (frames, speed) = Inspect(bytes);
    var relative = "gifs/" + Guid.NewGuid().ToString("N") + ".gif";
    var fullPath = GetFullPath(relative);
    try
    {
        await using var output = new FileStream(fullPath, FileMode.CreateNew, FileAccess.Write, FileShare.None,
            81920, FileOptions.Asynchronous);
        await output.WriteAsync(bytes, cancellationToken);
    }
    catch
    {
        Delete(relative);
        throw;
    }
    return new StoredGif(relative, frames, speed);
}
    public string GetFullPath(string relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath))
            throw new ArgumentException("Путь к GIF-файлу отсутствует.");
        var relative = relativePath.Replace('\\', '/').TrimStart('/');
        var path = Path.GetFullPath(Path.Combine(root, relative));
        var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
        var prefix = Path.EndsInDirectorySeparator(root) ? root : root + Path.DirectorySeparatorChar;
        if (!path.StartsWith(prefix, comparison))
            throw new ArgumentException("Недопустимый путь к GIF-файлу.");
        return path;
    }

    public void Delete(string relativePath)
    {
        try { File.Delete(GetFullPath(relativePath)); }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or ArgumentException)
        {
            logger.LogWarning(exception, "Не удалось удалить файл GIF из хранилища.");
        }
    }

    private static (int Frames, float Speed) Inspect(byte[] bytes)
    {
        try
        {
            using var stream = new MemoryStream(bytes, false);
            using var reader = new BinaryReader(stream, Encoding.ASCII);
            var signature = Encoding.ASCII.GetString(reader.ReadBytes(6));
            if (signature is not ("GIF87a" or "GIF89a")) throw new InvalidDataException();
            var width = reader.ReadUInt16();
            var height = reader.ReadUInt16();
            if (width == 0 || height == 0 || width > 4096 || height > 4096) throw new InvalidDataException();
            var packed = reader.ReadByte();
            reader.ReadByte();
            reader.ReadByte();
            var globalPalette = (packed & 0x80) != 0;
            var globalColors = 1 << ((packed & 7) + 1);
            if (globalPalette) Skip(reader, 3 * globalColors);
            var frames = 0;
            var totalDelay = 0L;
            var nextDelay = 10;
            while (true)
            {
                var marker = reader.ReadByte();
                if (marker == 0x3b)
                {
                    if (frames == 0 || stream.Position != stream.Length) throw new InvalidDataException();
                    return (frames, (float)(100.0 * frames / totalDelay));
                }
                if (marker == 0x21)
                {
                    var label = reader.ReadByte();
                    if (label == 0xf9)
                    {
                        if (reader.ReadByte() != 4) throw new InvalidDataException();
                        reader.ReadByte();
                        var delay = reader.ReadUInt16();
                        nextDelay = delay == 0 ? 10 : delay;
                        reader.ReadByte();
                        if (reader.ReadByte() != 0) throw new InvalidDataException();
                    }
                    else SkipBlocks(reader);
                    continue;
                }
                if (marker != 0x2c) throw new InvalidDataException();
                var left = reader.ReadUInt16();
                var top = reader.ReadUInt16();
                var frameWidth = reader.ReadUInt16();
                var frameHeight = reader.ReadUInt16();
                if (frameWidth == 0 || frameHeight == 0 || left + frameWidth > width || top + frameHeight > height)
                    throw new InvalidDataException();
                var localPacked = reader.ReadByte();
                var localPalette = (localPacked & 0x80) != 0;
                var colors = localPalette ? 1 << ((localPacked & 7) + 1) : globalColors;
                if (localPalette) Skip(reader, 3 * colors);
                if (!localPalette && !globalPalette) throw new InvalidDataException();
                var codeSize = reader.ReadByte();
                if (codeSize is < 2 or > 8) throw new InvalidDataException();
                ValidateLzw(ReadBlocks(reader), codeSize, colors, frameWidth * frameHeight);
                if (++frames > 1000) throw new InvalidDataException();
                totalDelay += nextDelay;
                nextDelay = 10;
            }
        }
        catch (Exception exception) when (exception is EndOfStreamException or InvalidDataException)
        {
            throw new ArgumentException("Файл не является корректным GIF. Допустимы размеры до 4096×4096 и до 1000 кадров.");
        }
    }

    private static byte[] ReadBlocks(BinaryReader reader)
    {
        using var data = new MemoryStream();
        int size;
        while ((size = reader.ReadByte()) != 0)
        {
            var block = reader.ReadBytes(size);
            if (block.Length != size) throw new EndOfStreamException();
            data.Write(block);
        }
        return data.ToArray();
    }

    private static void ValidateLzw(byte[] data, int minimumCodeSize, int paletteSize, int expectedPixels)
    {
        var clear = 1 << minimumCodeSize;
        var end = clear + 1;
        var nextCode = end + 1;
        var codeSize = minimumCodeSize + 1;
        var lengths = new int[4096];
        var firstColors = new int[4096];
        for (var i = 0; i < clear; i++) { lengths[i] = 1; firstColors[i] = i; }
        var bitOffset = 0;
        var previous = -1;
        var pixels = 0L;

        int ReadCode()
        {
            if (bitOffset + codeSize > data.Length * 8) throw new InvalidDataException();
            var offset = bitOffset >> 3;
            uint bits = data[offset];
            if (offset + 1 < data.Length) bits |= (uint)data[offset + 1] << 8;
            if (offset + 2 < data.Length) bits |= (uint)data[offset + 2] << 16;
            var code = (int)((bits >> (bitOffset & 7)) & ((1u << codeSize) - 1));
            bitOffset += codeSize;
            return code;
        }

        while (true)
        {
            var code = ReadCode();
            if (code == clear)
            {
                nextCode = end + 1;
                codeSize = minimumCodeSize + 1;
                previous = -1;
                continue;
            }
            if (code == end)
            {
                if (pixels != expectedPixels) throw new InvalidDataException();
                return;
            }

            int length, first;
            if (code < nextCode && code < 4096)
            {
                length = lengths[code];
                first = firstColors[code];
                if (length <= 0 || first >= paletteSize) throw new InvalidDataException();
            }
            else if (code == nextCode && previous >= 0 && nextCode < 4096)
            {
                length = lengths[previous] + 1;
                first = firstColors[previous];
            }
            else throw new InvalidDataException();

            pixels += length;
            if (pixels > expectedPixels) throw new InvalidDataException();
            if (previous >= 0 && nextCode < 4096)
            {
                lengths[nextCode] = lengths[previous] + 1;
                firstColors[nextCode] = firstColors[previous];
                nextCode++;
                if (nextCode == (1 << codeSize) && codeSize < 12) codeSize++;
            }
            previous = code;
        }
    }

    private static int SkipBlocks(BinaryReader reader)
    {
        var count = 0;
        int size;
        while ((size = reader.ReadByte()) != 0) { Skip(reader, size); count += size; }
        return count;
    }

    private static void Skip(BinaryReader reader, int count)
    {
        if (reader.BaseStream.Position + count > reader.BaseStream.Length) throw new EndOfStreamException();
        reader.BaseStream.Seek(count, SeekOrigin.Current);
    }
}
