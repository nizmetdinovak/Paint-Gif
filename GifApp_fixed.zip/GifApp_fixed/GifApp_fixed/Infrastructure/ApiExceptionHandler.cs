using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;

namespace GifApp.Infrastructure;

public sealed class ApiExceptionHandler(ILogger<ApiExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext context, Exception exception, CancellationToken cancellationToken)
    {
        if (exception is OperationCanceledException && context.RequestAborted.IsCancellationRequested)
            return true;
        var mysql = FindMySqlError(exception);
        var (status, title, detail) = exception switch
        {
            BadHttpRequestException bad => (bad.StatusCode, "Некорректный запрос", "Проверьте формат и размер запроса."),
            ArgumentException or InvalidDataException => (400, "Некорректные данные", exception.Message),
            _ when mysql?.Number == 1062 => (409, "Конфликт данных", "Запись с такими уникальными значениями уже существует."),
            _ when mysql?.Number is 1451 or 1452 => (409, "Связанные данные изменились", "Проверьте существование связанных записей и повторите действие."),
            _ when exception is MySqlException => (503, "База данных недоступна", "Не удалось подключиться к базе данных. Повторите попытку позже."),
            _ => (500, "Не удалось выполнить действие", "Произошла ошибка сервера. Повторите попытку позже.")
        };
        if (status >= 500)
            logger.LogError(exception, "Ошибка API: {Method} {Path}", context.Request.Method, context.Request.Path);
        context.Response.StatusCode = status;
        await context.Response.WriteAsJsonAsync(new ProblemDetails
        {
            Status = status, Title = title, Detail = detail, Instance = context.Request.Path
        }, options: null, contentType: "application/problem+json", cancellationToken: cancellationToken);
        return true;
    }

    private static MySqlException? FindMySqlError(Exception exception)
    {
        for (Exception? current = exception; current is not null; current = current.InnerException)
            if (current is MySqlException mysql) return mysql;
        return null;
    }
}
