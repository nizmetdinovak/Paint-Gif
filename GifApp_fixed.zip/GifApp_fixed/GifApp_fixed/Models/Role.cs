using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("roles")]
public class Role
{
    [Key, Column("id_role")] public int IdRole { get; set; }
    [Column("role_name"), MaxLength(5)] public string RoleName { get; set; } = "";
}
