using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("publications")]
public class Publication
{
    [Key, Column("id_publication")] public int IdPublication { get; set; }
    [Column("id_gif")] public int IdGif { get; set; }
    [Column("id_user")] public int IdUser { get; set; }
    [Column("publication_date", TypeName = "datetime(3)")] public DateTime PublicationDate { get; set; }
}
