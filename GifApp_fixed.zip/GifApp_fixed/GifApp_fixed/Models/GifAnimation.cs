using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("gif_animations")]
public class GifAnimation
{
    [Key, Column("id_gif")] public int IdGif { get; set; }
    [Column("name_gif"), MaxLength(35)] public string NameGif { get; set; } = "";
    [Column("description_gif")] public string DescriptionGif { get; set; } = "";
    [Column("creation_date", TypeName = "date")] public DateTime CreationDate { get; set; }
    [Column("id_user")] public int IdUser { get; set; }
    [Column("frame_count")] public int FrameCount { get; set; }
    [Column("playback_speed")] public float PlaybackSpeed { get; set; }
    [Column("gif_path")] public string GifPath { get; set; } = "";
}
