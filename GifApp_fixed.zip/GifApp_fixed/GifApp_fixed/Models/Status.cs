using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("statuses")]
public class Status
{
    [Key, Column("id_status")] public int IdStatus { get; set; }
    [Column("status"), MaxLength(9)] public string StatusName { get; set; } = "";
}
