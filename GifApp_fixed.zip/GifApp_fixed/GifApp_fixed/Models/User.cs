using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("users")]
public class User
{
    [Key, Column("id_user")] public int IdUser { get; set; }
    [Column("id_role")] public int IdRole { get; set; }
    [Column("user_name"), MaxLength(25)] public string UserName { get; set; } = "";
    [Column("user_email"), MaxLength(25)] public string UserEmail { get; set; } = "";
    [Column("user_password"), MaxLength(8)] public string UserPassword { get; set; } = "";
    [Column("id_status")] public int IdStatus { get; set; }
    [Column("registration_date", TypeName = "datetime")]public DateTime? RegistrationDate { get; set; }
}
