using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("type_reactions")]
public class TypeReaction
{
    [Key, Column("id_type_reaction")] public int IdTypeReaction { get; set; }
    [Column("name_type_reaction"), MaxLength(7)] public string NameTypeReaction { get; set; } = "";
}
