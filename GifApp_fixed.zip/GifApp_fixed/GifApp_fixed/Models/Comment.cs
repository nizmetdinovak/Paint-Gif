using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("comments")]
public class Comment
{
    [Key, Column("id_comment")] public int IdComment { get; set; }
    [Column("id_publication")] public int IdPublication { get; set; }
    [Column("id_user")] public int IdUser { get; set; }
    [Column("comment_text")] public string CommentText { get; set; } = "";
    [Column("comment_date", TypeName = "date")] public DateTime CommentDate { get; set; }
}
