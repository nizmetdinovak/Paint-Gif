using Microsoft.EntityFrameworkCore;

namespace GifApp.Models;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Status> Statuses => Set<Status>();
    public DbSet<GifAnimation> GifAnimations => Set<GifAnimation>();
    public DbSet<Publication> Publications => Set<Publication>();
    public DbSet<Comment> Comments => Set<Comment>();
    public DbSet<Reaction> Reactions => Set<Reaction>();
    public DbSet<TypeReaction> TypeReactions => Set<TypeReaction>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("utf8mb4_0900_ai_ci");
        modelBuilder.Entity<User>().Property(u => u.RegistrationDate).HasDefaultValueSql("CURRENT_TIMESTAMP");
        modelBuilder.Entity<User>().Property(x => x.IdUser).ValueGeneratedOnAdd();
        modelBuilder.Entity<Role>().Property(x => x.IdRole).ValueGeneratedOnAdd();
        modelBuilder.Entity<Status>().Property(x => x.IdStatus).ValueGeneratedOnAdd();
        modelBuilder.Entity<GifAnimation>().Property(x => x.IdGif).ValueGeneratedOnAdd();
        modelBuilder.Entity<Publication>().Property(x => x.IdPublication).ValueGeneratedOnAdd();
        modelBuilder.Entity<Comment>().Property(x => x.IdComment).ValueGeneratedOnAdd();
        modelBuilder.Entity<Reaction>().Property(x => x.IdReaction).ValueGeneratedOnAdd();
        modelBuilder.Entity<TypeReaction>().Property(x => x.IdTypeReaction).ValueGeneratedOnAdd();
        modelBuilder.Entity<User>().HasIndex(x => x.UserName).IsUnique().HasDatabaseName("ux_users_name");
        modelBuilder.Entity<User>().HasIndex(x => x.UserEmail).IsUnique().HasDatabaseName("ux_users_email");
        modelBuilder.Entity<Reaction>().HasIndex(x => new { x.IdPublication, x.IdUser })
            .IsUnique().HasDatabaseName("ux_reactions_publication_user");
        modelBuilder.Entity<User>().HasOne<Role>().WithMany().HasForeignKey(x => x.IdRole).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<User>().HasOne<Status>().WithMany().HasForeignKey(x => x.IdStatus).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<GifAnimation>().HasOne<User>().WithMany().HasForeignKey(x => x.IdUser).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Publication>().HasOne<GifAnimation>().WithMany().HasForeignKey(x => x.IdGif).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Publication>().HasOne<User>().WithMany().HasForeignKey(x => x.IdUser).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Comment>().HasOne<Publication>().WithMany().HasForeignKey(x => x.IdPublication).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Comment>().HasOne<User>().WithMany().HasForeignKey(x => x.IdUser).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Reaction>().HasOne<Publication>().WithMany().HasForeignKey(x => x.IdPublication).OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<Reaction>().HasOne<User>().WithMany().HasForeignKey(x => x.IdUser).OnDelete(DeleteBehavior.Restrict);
        modelBuilder.Entity<Reaction>().HasOne<TypeReaction>().WithMany().HasForeignKey(x => x.IdTypeReaction).OnDelete(DeleteBehavior.Restrict);
    }
}
