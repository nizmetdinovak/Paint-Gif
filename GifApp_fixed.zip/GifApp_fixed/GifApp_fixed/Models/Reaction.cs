using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GifApp.Models;

[Table("reactions")]
public class Reaction
{
    [Key, Column("id_reaction")] public int IdReaction { get; set; }
    [Column("id_publication")] public int IdPublication { get; set; }
    [Column("id_user")] public int IdUser { get; set; }
    [Column("id_type_reaction")] public int IdTypeReaction { get; set; }
    [Column("reaction_date", TypeName = "date")] public DateTime ReactionDate { get; set; }
}
