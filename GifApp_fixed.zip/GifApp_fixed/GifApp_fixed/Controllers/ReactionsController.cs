using GifApp.Models;
using GifApp.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Controllers;

[ApiController]
[Route("api/reactions")]
public class ReactionsController : ControllerBase
{
    private readonly AppDbContext db;

    public ReactionsController(AppDbContext db)
    {
        this.db = db;
    }

    //  счётчики
    [HttpGet("{publicationId}")]
    public async Task<IActionResult> Counts(int publicationId)
    {
        var publication = await db.Publications
            .FirstOrDefaultAsync(p => p.IdPublication == publicationId);

        if (publication == null)
        {
            return NotFound("Публикация не найдена.");
        }

        var likes = await db.Reactions
            .CountAsync(r => r.IdPublication == publicationId && r.IdTypeReaction == 2);

        var dislikes = await db.Reactions
            .CountAsync(r => r.IdPublication == publicationId && r.IdTypeReaction == 1);

        return Ok(new { publicationId, likes, dislikes });
    }

    //  поставить или изменить реакцию
    [HttpPost]
    [Authorize(Roles = "user")]
    public async Task<IActionResult> SetReaction(ReactionRequest request)
    {
      
        if (request.IdTypeReaction != 1 && request.IdTypeReaction != 2)
        {
            return BadRequest("Тип реакции: 1 — дизлайк, 2 — лайк.");
        }

        var publication = await db.Publications
            .FirstOrDefaultAsync(p => p.IdPublication == request.IdPublication);

        if (publication == null)
        {
            return BadRequest("Публикация не найдена.");
        }

        var userId = User.GetUserId();

        // ищем старую реакцию  пользователя
        var reaction = await db.Reactions
            .FirstOrDefaultAsync(r => r.IdPublication == request.IdPublication && r.IdUser == userId);

        // если нет —-создаём
        if (reaction == null)
        {
            reaction = new Reaction
            {
                IdPublication = request.IdPublication,
                IdUser = userId,
                IdTypeReaction = request.IdTypeReaction,
                ReactionDate = DateTime.Today
            };
            db.Reactions.Add(reaction);
        }
        else
        {
            // если есть - меняем тип
            reaction.IdTypeReaction = request.IdTypeReaction;
            reaction.ReactionDate = DateTime.Today;
        }

        await db.SaveChangesAsync();

        return Ok(new
        {
            reaction.IdReaction,
            reaction.IdPublication,
            reaction.IdUser,
            reaction.IdTypeReaction,
            reaction.ReactionDate
        });
    }

    // получить свою реакцию на публикацию
[HttpGet("my/{publicationId}")]
[Authorize(Roles = "user")]
public async Task<IActionResult> GetMyReaction(int publicationId)
{
    var userId = User.GetUserId();
    
    var reaction = await db.Reactions
        .FirstOrDefaultAsync(r => r.IdPublication == publicationId && r.IdUser == userId);

    // Если реакции нет — возвращаем null
    if (reaction == null)
    {
        return Ok(null);
    }


    return Ok(new { idTypeReaction = reaction.IdTypeReaction });
}

    //  убрать свою реакцию
    [HttpDelete]
    [Authorize(Roles = "user")]
    public async Task<IActionResult> Remove(int publicationId)
    {
        var userId = User.GetUserId();

        var reaction = await db.Reactions
            .FirstOrDefaultAsync(r => r.IdPublication == publicationId && r.IdUser == userId);

        if (reaction == null)
        {
            return NotFound("Реакция не найдена.");
        }

        db.Reactions.Remove(reaction);
        await db.SaveChangesAsync();

        return NoContent();
    }
}

public class ReactionRequest
{
    public int IdPublication { get; set; }
    public int IdTypeReaction { get; set; }
}