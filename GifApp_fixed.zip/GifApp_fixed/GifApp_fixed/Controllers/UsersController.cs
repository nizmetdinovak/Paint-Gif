using System.ComponentModel.DataAnnotations;
using GifApp.Models;
using GifApp.Security;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Controllers;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext db;

    public UsersController(AppDbContext db)
    {
        this.db = db;
    }

    // все пользователи 
    [Authorize(Roles = "admin")]
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var users = await db.Users
            .Select(u => new
            {
                u.IdUser,
                u.UserName,
                u.UserEmail,
                u.IdRole,
                u.IdStatus
            })
            .ToListAsync();

        return Ok(users);
    }

    // пользователь по id 
    [Authorize(Roles = "admin")]
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.IdUser == id);

        if (user == null)
        {
            return NotFound();
        }

        return Ok(Profile(user));
    }

    // информация о себе
    [Authorize]
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var userId = User.GetUserId();

        var user = await db.Users
            .FirstOrDefaultAsync(u => u.IdUser == userId);

        if (user == null)
        {
            return Unauthorized();
        }

        return Ok(Profile(user));
    }

  
    [AllowAnonymous]
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request)
    {
        var name = request.UserName?.Trim() ?? "";
        var email = request.UserEmail?.Trim() ?? "";

        // проверяем имя
        if (string.IsNullOrWhiteSpace(name) || name.Length > 25)
        {
            return BadRequest("Имя пользователя обязательно и должно содержать не более 25 символов.");
        }

        // проверяем email
        var emailValidator = new EmailAddressAttribute();
        if (string.IsNullOrWhiteSpace(email) || email.Length > 25 || !emailValidator.IsValid(email))
        {
            return BadRequest("Введите корректный email длиной не более 25 символов.");
        }

    
        if (string.IsNullOrWhiteSpace(request.Password) || request.Password.Length > 8)
        {
            return BadRequest("Пароль обязателен и должен содержать не более 8 символов.");
        }

        // имя должно быть уникальным
        var nameExists = await db.Users.AnyAsync(u => u.UserName == name);
        if (nameExists)
        {
            return Conflict("Это имя пользователя уже занято.");
        }

        // email тоже должен быть уникальным
        var emailExists = await db.Users.AnyAsync(u => u.UserEmail == email);
        if (emailExists)
        {
            return Conflict("Этот email уже зарегистрирован.");
        }

        // проверяем, что в базе есть роль 2 и статус 1
        var hasRole = await db.Roles.AnyAsync(r => r.IdRole == 2);
        var hasStatus = await db.Statuses.AnyAsync(s => s.IdStatus == 1);

        if (!hasRole || !hasStatus)
        {
            return Problem("В базе отсутствуют обязательные роль и статус.", statusCode: 503);
        }

        // создаём пользователя
        var user = new User
        {
            UserName = name,
            UserEmail = email,
            UserPassword = request.Password,
            IdRole = 2,       
            IdStatus = 1      
        };

        db.Users.Add(user);
        await db.SaveChangesAsync();

        return StatusCode(StatusCodes.Status201Created, Profile(user));
    }

    //  вход
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var email = request.UserEmail?.Trim() ?? "";

        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrEmpty(request.Password))
        {
            return Unauthorized("Неверный email или пароль.");
        }

        // ищем пользователя по email
        var user = await db.Users
            .FirstOrDefaultAsync(u => u.UserEmail == email);

        // пароль сравниваем 
        if (user == null || user.UserPassword != request.Password)
        {
            return Unauthorized("Неверный email или пароль.");
        }

        // статус активен
        if (user.IdStatus != 1)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { message = "Пользователь заблокирован." });
        }

        // роль: 1 админ, 2  пользователь
        if (user.IdRole != 1 && user.IdRole != 2)
        {
            return StatusCode(StatusCodes.Status403Forbidden, new { message = "Роль не поддерживается." });
        }   

        // ставим cookie
        var principal = SessionCookieEvents.CreatePrincipal(user);
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            principal,
            new AuthenticationProperties { IsPersistent = false });

        return Ok(Profile(user));
    }

  
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return NoContent();
    }

    // ответ 
    private static object Profile(User user)
    {
        return new
        {
            user.IdUser,
            user.UserName,
            user.UserEmail,
            user.IdRole,
            user.IdStatus
        };
    }
}

public class RegisterRequest
{
    public string UserName { get; set; } = "";
    public string UserEmail { get; set; } = "";
    public string Password { get; set; } = "";
}

public class LoginRequest
{
    public string UserEmail { get; set; } = "";
    public string Password { get; set; } = "";
}