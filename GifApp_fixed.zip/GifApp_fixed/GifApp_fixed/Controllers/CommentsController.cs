using System.ComponentModel.DataAnnotations;
using System.Text;
using GifApp.Models;
using GifApp.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Controllers;

[ApiController]
[Route("api/comments")]
public class CommentsController : ControllerBase
{
    private readonly AppDbContext db;

    public CommentsController(AppDbContext db)
    {
        this.db = db;
    }

    //  комментарии к публикации
    [HttpGet]
    public async Task<IActionResult> GetByPublication(int publicationId)
    {
        // проверяем, что публикация существует
        var publication = await db.Publications
            .FirstOrDefaultAsync(p => p.IdPublication == publicationId);

        if (publication == null)
        {
            return NotFound("Публикация не найдена.");
        }

        // берём комментарии вместе с именами пользователей
        var comments = await (from c in db.Comments
                              join u in db.Users on c.IdUser equals u.IdUser
                              where c.IdPublication == publicationId
                              orderby c.CommentDate, c.IdComment
                              select new
                              {
                                  c.IdComment,
                                  c.IdPublication,
                                  c.IdUser,
                                  u.UserName,
                                  c.CommentText,
                                  c.CommentDate
                              })
                              .ToListAsync();

        return Ok(comments);
    }

    [HttpPost]
    [Authorize(Roles = "user")]
    public async Task<IActionResult> Create(CommentRequest request)
    {
        // текст не должен быть пустым
        if (string.IsNullOrWhiteSpace(request.CommentText))
        {
            return BadRequest("Комментарий не может быть пустым.");
        }

        // проверяем длину
        var text = request.CommentText.Trim();
        if (Encoding.UTF8.GetByteCount(text) > 65535)
        {
            return BadRequest("Комментарий слишком длинный.");
        }

        // проверяем, что публикация есть
        var publication = await db.Publications
            .FirstOrDefaultAsync(p => p.IdPublication == request.IdPublication);

        if (publication == null)
        {
            return BadRequest("Публикация не найдена.");
        }

        // создаём комментарий
        var comment = new Comment
        {
            IdPublication = request.IdPublication,
            IdUser = User.GetUserId(),
            CommentText = text,
            CommentDate = DateTime.Today
        };

        db.Comments.Add(comment);
        await db.SaveChangesAsync();

        return Ok(comment);
    }

    // удалить свой комментарий
    [HttpDelete("{id}")]
    [Authorize(Roles = "user")]
    public async Task<IActionResult> Delete(int id)
    {
        // ищем комментарий
        var comment = await db.Comments
            .FirstOrDefaultAsync(c => c.IdComment == id);

        if (comment == null)
        {
            return NotFound();
        }

        // удалять можно только свои
        if (comment.IdUser != User.GetUserId())
        {
            return Forbid();
        }

        db.Comments.Remove(comment);
        await db.SaveChangesAsync();

        return NoContent();
    }
}

public class CommentRequest
{
    public int IdPublication { get; set; }

    [Required]
    public string CommentText { get; set; } = "";
}