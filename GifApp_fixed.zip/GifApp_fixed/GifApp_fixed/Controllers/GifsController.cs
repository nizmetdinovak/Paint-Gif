    using System.ComponentModel.DataAnnotations;
    using System.Text;
    using GifApp.Models;
    using GifApp.Security;
    using GifApp.Services;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;

    namespace GifApp.Controllers;

    [ApiController]
    [Authorize(Roles = "user")]
    [Route("api/gifs")]
    public class GifsController : ControllerBase
    {
        private readonly AppDbContext db;
        private readonly GifFileStorage storage;

        public GifsController(AppDbContext db, GifFileStorage storage)
        {
            this.db = db;
            this.storage = storage;
        }

        // список гиф пользователя
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var userId = User.GetUserId();

            var gifs = await db.GifAnimations
                .Where(g => g.IdUser == userId)
                .OrderByDescending(g => g.CreationDate)
                .ToListAsync();

            return Ok(gifs.Select(ToResponse));
        }

        
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var gif = await db.GifAnimations.FirstOrDefaultAsync(g => g.IdGif == id);

            if (gif == null)
            {
                return NotFound();
            }

            if (gif.IdUser != User.GetUserId())
            {
                return Forbid();
            }

            return Ok(ToResponse(gif));
        }

        // файл гифки
        [HttpGet("{id}/file")]
        [AllowAnonymous]     
        public async Task<IActionResult> GetFile(int id)
        {
            var gif = await db.GifAnimations.FirstOrDefaultAsync(g => g.IdGif == id);

            if (gif == null)
            {
                return NotFound();
            }

            // if (gif.IdUser != User.GetUserId())
            // {
            //     return Forbid();
            // }

            var path = storage.GetFullPath(gif.GifPath); // относительный путь в абсолют

            if (!System.IO.File.Exists(path))
            {
                return NotFound("Файл GIF не найден.");
            }

            return PhysicalFile(path, "image/gif");
        }

        // новая гиф
        [HttpPost]
        public async Task<IActionResult> Create([FromForm] CreateGifRequest request)
        {
            if (request.File == null)
            {
                return BadRequest("Добавьте файл GIF.");
            }

            var description = request.DescriptionGif ?? "";

            var saved = await storage.SaveAsync(request.File);

            var gif = new GifAnimation
            {
                NameGif = request.NameGif,
                DescriptionGif = description,
                CreationDate = DateTime.Today,
                IdUser = User.GetUserId(),
                FrameCount = saved.FrameCount,
                PlaybackSpeed = saved.PlaybackSpeed,
                GifPath = saved.Path
            };

            db.GifAnimations.Add(gif);
            await db.SaveChangesAsync();

            return Ok(ToResponse(gif));
        }

        // редактируем 
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] UpdateGifRequest request)
        {
            var gif = await db.GifAnimations.FirstOrDefaultAsync(g => g.IdGif == id);

            if (gif == null)
            {
                return NotFound();
            }

            if (gif.IdUser != User.GetUserId())
            {
                return Forbid();
            }

            gif.NameGif = request.NameGif;
            gif.DescriptionGif = request.DescriptionGif ?? "";

            // если прислали новый файл - меняем
            if (request.File != null)
            {
                var oldPath = gif.GifPath;
                var saved = await storage.SaveAsync(request.File);

                gif.GifPath = saved.Path;
                gif.FrameCount = saved.FrameCount;
                gif.PlaybackSpeed = saved.PlaybackSpeed;

                storage.Delete(oldPath);
            }

            await db.SaveChangesAsync();

            return Ok(ToResponse(gif));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var gif = await db.GifAnimations.FirstOrDefaultAsync(g => g.IdGif == id);

            if (gif == null)
            {
                return NotFound();
            }

            if (gif.IdUser != User.GetUserId())
            {
                return Forbid();
            }

            var hasPublications = await db.Publications.AnyAsync(p => p.IdGif == id);
            if (hasPublications)
            {
                return BadRequest("Сначала удалите публикации.");
            }

            db.GifAnimations.Remove(gif);
            await db.SaveChangesAsync();

            storage.Delete(gif.GifPath);

            return NoContent();
        }

        // превращаем гифку в ответ
        private static object ToResponse(GifAnimation gif)
        {
            return new
            {
                gif.IdGif,
                gif.NameGif,
                gif.DescriptionGif,
                gif.CreationDate,
                gif.IdUser,
                gif.FrameCount,
                gif.PlaybackSpeed,
                FileUrl = "/api/gifs/" + gif.IdGif + "/file"
            };
        }
    }

    public class CreateGifRequest
    {
        [Required, StringLength(35)]
        public string NameGif { get; set; } = "";

        public string? DescriptionGif { get; set; }

        [Required]
        public IFormFile? File { get; set; }
    }

    public class UpdateGifRequest
    {
        [Required, StringLength(35)]
        public string NameGif { get; set; } = "";

        public string? DescriptionGif { get; set; }

        public IFormFile? File { get; set; }
    }