using GifApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Controllers;

[ApiController]
[Authorize(Roles = "admin")]
[Route("api/statistics")]
public class StatisticsController : ControllerBase
{
    private readonly AppDbContext db;

    public StatisticsController(AppDbContext db)
    {
        this.db = db;
    }

    [HttpGet]
    public async Task<IActionResult> Get()
    {
        // Популярные публикации
        var topPublications = await (
            from p in db.Publications
            join g in db.GifAnimations on p.IdGif equals g.IdGif
            join u in db.Users on p.IdUser equals u.IdUser
            select new
            {
                p.IdPublication,
                g.NameGif,
                u.UserName,
                p.PublicationDate,

                Likes = db.Reactions.Count(r =>
                    r.IdPublication == p.IdPublication &&
                    r.IdTypeReaction == 2),

                Dislikes = db.Reactions.Count(r =>
                    r.IdPublication == p.IdPublication &&
                    r.IdTypeReaction == 1)
            })
            .OrderByDescending(p => p.Likes)
            .ThenByDescending(p => p.PublicationDate)
            .Take(5)
            .ToListAsync();

        // Общие показатели
        var users = await db.Users.CountAsync();

        var activeUsers = await db.Users.CountAsync(u =>
            u.IdStatus == 1);

        var blockedUsers = await db.Users.CountAsync(u =>
            u.IdStatus == 2);

        var gifs = await db.GifAnimations.CountAsync();
        var publications = await db.Publications.CountAsync();
        var comments = await db.Comments.CountAsync();

        var likes = await db.Reactions.CountAsync(r =>
            r.IdTypeReaction == 2);

        var dislikes = await db.Reactions.CountAsync(r =>
            r.IdTypeReaction == 1);

        var unknownRegistrationDates = await db.Users.CountAsync(u =>
            !u.RegistrationDate.HasValue);

        // Публикации по дням
        var publicationsByDay = await db.Publications
            .GroupBy(p => p.PublicationDate.Date)
            .Select(g => new
            {
                date = g.Key,
                count = g.Count()
            })
            .OrderBy(g => g.date)
            .ToListAsync();

        // Регистрации по дням
        var registrationsByDay = await db.Users
            .Where(u => u.RegistrationDate.HasValue)
            .GroupBy(u => u.RegistrationDate!.Value.Date)
            .Select(g => new
            {
                date = g.Key,
                count = g.Count()
            })
            .OrderBy(g => g.date)
            .ToListAsync();

        return Ok(new
        {
            users,
            activeUsers,
            blockedUsers,
            gifs,
            publications,
            comments,
            likes,
            dislikes,
            unknownRegistrationDates,
            topPublications,
            publicationsByDay,
            registrationsByDay
        });
    }
}