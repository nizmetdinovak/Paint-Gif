using GifApp.Models;
using GifApp.Security;
using GifApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Controllers;

[ApiController]
[Route("api/publications")]
public class PublicationsController : ControllerBase
{
    private readonly AppDbContext db;
    private readonly GifFileStorage storage;

    public PublicationsController(AppDbContext db, GifFileStorage storage)
    {
        this.db = db;
        this.storage = storage;
    }

    // лента
    [HttpGet]
    public async Task<IActionResult> Feed()
    {
        var publications = await (from p in db.Publications
                                  join g in db.GifAnimations on p.IdGif equals g.IdGif
                                  join u in db.Users on p.IdUser equals u.IdUser
                                  orderby p.PublicationDate descending
                                  select new
                                  {
                                      p.IdPublication,
                                      p.PublicationDate,
                                      u.UserName,
                                      g.NameGif,
                                      g.DescriptionGif,
                                      GifUrl = "/api/publications/" + p.IdPublication + "/gif",
                                      Likes = db.Reactions.Count(r => r.IdPublication == p.IdPublication && r.IdTypeReaction == 2),
                                      Dislikes = db.Reactions.Count(r => r.IdPublication == p.IdPublication && r.IdTypeReaction == 1),
                                      CommentCount = db.Comments.Count(c => c.IdPublication == p.IdPublication)
                                  }).ToListAsync();

        return Ok(publications);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var publication = await (from p in db.Publications
                                 join g in db.GifAnimations on p.IdGif equals g.IdGif
                                 join u in db.Users on p.IdUser equals u.IdUser
                                 where p.IdPublication == id
                                 select new
                                 {
                                     p.IdPublication,
                                     p.PublicationDate,
                                     u.UserName,
                                     g.NameGif,
                                     g.DescriptionGif,
                                     GifUrl = "/api/publications/" + p.IdPublication + "/gif",
                                     Likes = db.Reactions.Count(r => r.IdPublication == p.IdPublication && r.IdTypeReaction == 2),
                                     Dislikes = db.Reactions.Count(r => r.IdPublication == p.IdPublication && r.IdTypeReaction == 1),
                                     CommentCount = db.Comments.Count(c => c.IdPublication == p.IdPublication)
                                 }).FirstOrDefaultAsync();

        if (publication == null)
        {
            return NotFound();
        }

        return Ok(publication);
    }

    // файл GIF
    [HttpGet("{id}/gif")]
    public async Task<IActionResult> GetGif(int id)
    {
        var publication = await db.Publications
            .FirstOrDefaultAsync(p => p.IdPublication == id);

        if (publication == null)
        {
            return NotFound();
        }

        var gif = await db.GifAnimations
            .FirstOrDefaultAsync(g => g.IdGif == publication.IdGif);

        if (gif == null)
        {
            return NotFound();
        }

        var path = storage.GetFullPath(gif.GifPath);

        if (!System.IO.File.Exists(path))
        {
            return NotFound("Файл GIF не найден.");
        }

        return PhysicalFile(path, "image/gif");
    }

    // опубликовать свою GIF
    [HttpPost]
    [Authorize(Roles = "user")]
    public async Task<IActionResult> Create(PublicationRequest request)
    {
        var gif = await db.GifAnimations
            .FirstOrDefaultAsync(g => g.IdGif == request.IdGif);

        if (gif == null)
        {
            return BadRequest("GIF не найдена.");
        }

        if (gif.IdUser != User.GetUserId())
        {
            return Forbid();
        }

        // проверка: не опубликована ли уже эта GIF этим пользователем
        var alreadyPublished = await db.Publications
            .AnyAsync(p => p.IdGif == request.IdGif && p.IdUser == User.GetUserId());

        if (alreadyPublished)
        {
            return BadRequest("Эта GIF уже опубликована.");
        }

        var publication = new Publication
        {
            IdGif = gif.IdGif,
            IdUser = User.GetUserId(),
            PublicationDate = DateTime.Now
        };

        db.Publications.Add(publication);
        await db.SaveChangesAsync();

        return Ok(publication);
    }

    // удалить свою публикацию
   // удалить публикацию (свою — юзер, любую — админ)
[HttpDelete("{id}")]
[Authorize(Roles = "user,admin")] // ← пускаем и юзеров, и админов
public async Task<IActionResult> Delete(int id)
{
    var publication = await db.Publications
        .FirstOrDefaultAsync(p => p.IdPublication == id);

    if (publication == null)
    {
        return NotFound();
    }

    // Получаем id и роль из cookie
    var userId = User.GetUserId();
    var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

    // Если это НЕ админ и это НЕ его публикация — запрещаем
    if (role != "admin" && publication.IdUser != userId)
    {
        return Forbid();
    }

    db.Publications.Remove(publication);
    await db.SaveChangesAsync();

    return NoContent();
}
}

public class PublicationRequest
{
    public int IdGif { get; set; }
}