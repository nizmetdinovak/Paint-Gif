using GifApp.Models;
using GifApp.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Controllers;

[ApiController]
[Authorize(Roles = "admin")]
[Route("api/admin")]
public class AdminController : ControllerBase
{
    private readonly AppDbContext db;

    public AdminController(AppDbContext db)
    {
        this.db = db;
    }

    //  список пользователей
    [HttpGet("users")]
    public async Task<IActionResult> GetUsers()
    {
        var users = await db.Users
            .OrderBy(u => u.IdUser)
            .Select(u => new
            {
                u.IdUser,
                u.UserName,
                u.UserEmail,
                u.IdRole,
                u.IdStatus
            })
            .ToListAsync();

        return Ok(users);
    }

    //  блокировка
    [HttpPut("users/{id}/status")]
    public async Task<IActionResult> SetUserStatus(int id, UserStatusRequest request)
    {

        if (request.IdStatus != 1 && request.IdStatus != 2)
        {
            return BadRequest("Статус: 1  активен, 2  заблокирован.");
        }

        // нельзя заблокировать самого себя
        if (id == User.GetUserId() && request.IdStatus == 2)
        {
            return BadRequest("Нельзя заблокировать свою учётную запись.");
        }

        var user = await db.Users.FirstOrDefaultAsync(u => u.IdUser == id);
        if (user == null)
        {
            return NotFound();
        }

        user.IdStatus = request.IdStatus;
        await db.SaveChangesAsync();

        return Ok(new { user.IdUser, user.IdStatus });
    }

    // удалить публикацию
    [HttpDelete("publications/{id}")]
    public async Task<IActionResult> DeletePublication(int id)
    {
        var publication = await db.Publications.FirstOrDefaultAsync(p => p.IdPublication == id);
        if (publication == null)
        {
            return NotFound();
        }

        db.Publications.Remove(publication);
        await db.SaveChangesAsync();

        return NoContent();
    }

    //  удалить комментарий
    [HttpDelete("comments/{id}")]
    public async Task<IActionResult> DeleteComment(int id)
    {
        var comment = await db.Comments.FirstOrDefaultAsync(c => c.IdComment == id);
        if (comment == null)
        {
            return NotFound();
        }

        db.Comments.Remove(comment);
        await db.SaveChangesAsync();

        return NoContent();
    }
}

public class UserStatusRequest
{
    public int IdStatus { get; set; }
}