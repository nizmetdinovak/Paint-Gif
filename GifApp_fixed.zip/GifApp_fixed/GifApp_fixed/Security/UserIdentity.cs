using System.Globalization;
using System.Security.Claims;

namespace GifApp.Security;

public static class UserIdentity
{
    public static int GetUserId(this ClaimsPrincipal user)
    {
        if (int.TryParse(user.FindFirstValue(ClaimTypes.NameIdentifier), NumberStyles.None,
            CultureInfo.InvariantCulture, out var id) && id > 0)
            return id;
        throw new InvalidOperationException("Не удалось определить текущего пользователя.");
    }
}
