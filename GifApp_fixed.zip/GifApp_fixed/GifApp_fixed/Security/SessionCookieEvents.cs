using System.Globalization;
using System.Security.Claims;
using GifApp.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;

namespace GifApp.Security;

public sealed class SessionCookieEvents(AppDbContext db) : CookieAuthenticationEvents
{
    public override async Task ValidatePrincipal(CookieValidatePrincipalContext context)
    {
        var value = context.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
        var user = int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out var id)
            ? await db.Users.AsNoTracking().SingleOrDefaultAsync(u => u.IdUser == id, context.HttpContext.RequestAborted)
            : null;
        if (user is null || user.IdStatus != 1 || user.IdRole is not (1 or 2))
        {
            context.RejectPrincipal();
            await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return;
        }
        var role = user.IdRole == 1 ? "admin" : "user";
        var principal = context.Principal!;
        if (principal.FindFirstValue(ClaimTypes.Role) != role ||
            principal.FindFirstValue(ClaimTypes.Name) != user.UserName)
        {
            context.ReplacePrincipal(CreatePrincipal(user));
            context.ShouldRenew = true;
        }
    }

    public static ClaimsPrincipal CreatePrincipal(User user) => new(new ClaimsIdentity(
    [
        new Claim(ClaimTypes.NameIdentifier, user.IdUser.ToString(CultureInfo.InvariantCulture)),
        new Claim(ClaimTypes.Name, user.UserName),
        new Claim(ClaimTypes.Role, user.IdRole == 1 ? "admin" : "user")
    ], CookieAuthenticationDefaults.AuthenticationScheme));

    public override Task RedirectToLogin(RedirectContext<CookieAuthenticationOptions> context)
    {
        context.Response.StatusCode = StatusCodes.Status401Unauthorized;
        return context.Response.WriteAsJsonAsync(new { message = "Для этого действия необходимо войти в аккаунт." });
    }

    public override Task RedirectToAccessDenied(RedirectContext<CookieAuthenticationOptions> context)
    {
        context.Response.StatusCode = StatusCodes.Status403Forbidden;
        return context.Response.WriteAsJsonAsync(new { message = "Недостаточно прав для этого действия." });
    }
}
