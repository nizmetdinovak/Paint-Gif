using GifApp.Infrastructure;
using GifApp.Models;
using GifApp.Security;
using GifApp.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

//  подключение к базе
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

if (string.IsNullOrEmpty(connectionString))
{
    throw new Exception("Нет строки подключения ConnectionStrings__DefaultConnection.");
}

// Подключаем MySQL
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 0))));

// Контроллеры и Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "GifApp API", Version = "v1" });
});

// Обработка ошибок
builder.Services.AddExceptionHandler<ApiExceptionHandler>();
builder.Services.AddProblemDetails();

// Хранилище файлов
builder.Services.AddSingleton<GifFileStorage>();

// Ключи для шифрования cookie
var keysPath = builder.Configuration["DataProtection:KeysPath"] ?? "data/keys";
keysPath = Path.GetFullPath(keysPath);
Directory.CreateDirectory(keysPath);
builder.Services.AddDataProtection()
    .SetApplicationName("GifApp")
    .PersistKeysToFileSystem(new DirectoryInfo(keysPath));

// Аутентификация через cookie
builder.Services.AddScoped<SessionCookieEvents>();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.Name = "gifapp.session";
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.EventsType = typeof(SessionCookieEvents);
    });
builder.Services.AddAuthorization();

// Собираем приложение
var app = builder.Build();

// Обработка ошибок
app.UseExceptionHandler();

// Swagger
if (builder.Configuration.GetValue("Swagger:Enabled", true))
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Аутентификация и авторизация
app.UseAuthentication();
app.UseAuthorization();

// Контроллеры
app.MapControllers();

app.Run();